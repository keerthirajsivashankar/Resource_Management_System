let isSidebarOpen = true;

function toggleNav() {
    if (isSidebarOpen) {
        closeNav();
    } else {
        openNav();
        isSidebarOpen = true; // Update the state
    }
}

function openNav() {
    document.getElementById("mySidenav").style.width = "230px";
    document.getElementById("main").style.marginLeft = "230px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
    isSidebarOpen = false; // Update the state
}

// Close sidebar by default when the button is clicked for the first time
document.getElementById("ham").addEventListener("click", function() {
    toggleNav();
    this.removeEventListener("click", arguments.callee); // Remove the event listener after first click
});
